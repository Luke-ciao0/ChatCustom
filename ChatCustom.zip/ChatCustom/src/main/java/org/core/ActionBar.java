package org.core;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class ActionBar implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Solo i giocatori possono usare questo comando.");
            return true;
        }

        if (args.length < 4) {
            sender.sendMessage("Uso: /title <destinatario> <tipo> <titolo> <sottotitolo>");
            return true;
        }

        Player p = (Player) sender;

        String targetType = args[0].toLowerCase();
        String messageType = args[1].toLowerCase();

        StringBuilder msgBuilder = new StringBuilder();
        for (int i = 2; i < args.length; i++) {
            msgBuilder.append(args[i]).append(" ");
        }
        String message = msgBuilder.toString().trim();


        // Prefissi
        String prefix;

        switch (messageType) {
            case "log":
                prefix = "§6§lʟᴏɢ §7» §f";
                break;
            case "computer":
                prefix = "§6§lᴄᴏᴍᴘᴜᴛᴇʀ §7» §f";
                break;
            case "errore":
                prefix = "§6§lᴇʀʀᴏʀᴇ §7» §f";
                break;
            case "avviso":
                prefix = "§6§lᴀᴠᴠɪꜱᴏ §7» §f";
                break;
            case "roleplay":
                prefix = "§6§lʀᴏʟᴇᴘʟᴀʏ §7» §f";
                break;
            default:
                prefix = "§6§lᴀʟᴛʀᴏ §7» §f";
                break;
        }

        String finalMessage = prefix + message;

        switch (targetType) {

            case "broadcast":
                for (Player all : Bukkit.getOnlinePlayers()) {
                    sendActionBar(all, finalMessage);
                }
                break;

            case "private":
                sendActionBar(p, finalMessage);
                break;

            case "staff":
                for (Player all : Bukkit.getOnlinePlayers()) {
                    if (all.hasPermission("rp.staff.*")) {
                        sendActionBar(all, finalMessage);
                    }
                }
                break;

            default:
                p.sendMessage("Destinatario non valido.");
                break;
        }

        return true;
    }

    private void sendActionBar(Player p, String title) {
        p.sendActionBar(title);
    }



    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {

        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.add("broadcast");
            completions.add("private");
            completions.add("staff");
        }

        if (args.length == 2) {
            completions.add("log");
            completions.add("computer");
            completions.add("errore");
            completions.add("avviso");
            completions.add("roleplay");
        }

        return completions;
    }
}