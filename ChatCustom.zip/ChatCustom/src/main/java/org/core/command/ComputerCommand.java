package org.core.command;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.core.Listener.ComputerListener;

import java.util.Collections;

public class ComputerCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Solo i giocatori possono usare questo comando.");
            return true;
        }

        Player p = (Player) sender;
        ItemStack item = new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            meta.setDisplayName("§fᴄᴏᴍᴘᴜᴛᴇʀ ᴄʟᴀꜱꜱɪᴄ");
            meta.setLore(Collections.singletonList(" §f" + "§7Tasto destro per aprire il computer."));
            meta.setCustomModelData(3);
            item.setItemMeta(meta);
        }

        // p.sendMessage("§6§lʀᴏʟᴇᴘʟᴀʏ §7» §fGivvato un computer a " + p.getName());
        ComputerListener.openGUI(p);
        // p.getInventory().addItem(item);

        return true;
    }
}
