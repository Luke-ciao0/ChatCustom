package org.core.Listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {
    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        String p = event.getPlayer().getName();
        String m = event.getMessage();

        event.setFormat(p + " §7» §f" + m);
    }
}
