package org.core.Listener;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.core.main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ComputerListener implements Listener {

    private main plugin;

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {

        if (event.getAction() != Action.RIGHT_CLICK_AIR &&
                event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player p = event.getPlayer();
        ItemStack i = p.getInventory().getItemInMainHand();

        if (i == null || i.getType() == Material.AIR) {
            return;
        }

        if (i.getType() == Material.PAPER) {
            openGUI(p);
        }
    }

    public static ItemStack createItem(Material mat, String name, int cmd) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(name);
        meta.setCustomModelData(cmd);

        item.setItemMeta(meta);
        return item;
    }

    public static void openGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, "§fᴄᴏᴍᴘᴜᴛᴇʀ");

        gui.setItem(48, createItem(Material.PAPER, "§fᴛᴏʀɴᴀ ɪɴᴅɪᴇᴛʀᴏ", 2));
        gui.setItem(49, createItem(Material.PAPER, "§fᴀɢɢɪᴜɴɢɪ ᴜɴ ꜰɪʟᴇ", 43));
        gui.setItem(50, createItem(Material.PAPER, "§fᴀɢɢɪᴜɴɢɪ ᴜɴᴀ ᴄᴀʀᴛᴇʟʟᴀ", 43));

        gui.setItem(45, createItem(Material.PAPER, "ᴀᴠᴀɴᴛɪ" , 12));
        gui.setItem(53, createItem(Material.PAPER, "ɪɴᴅɪᴇᴛʀᴏ", 13));

        gui.setItem(46, createItem(Material.BLACK_STAINED_GLASS_PANE, " ", 1));
        gui.setItem(47, createItem(Material.BLACK_STAINED_GLASS_PANE, " ", 1));
        gui.setItem(51, createItem(Material.BLACK_STAINED_GLASS_PANE, " ", 1));
        gui.setItem(52, createItem(Material.BLACK_STAINED_GLASS_PANE, " ", 1));

        player.openInventory(gui);
    }


    public static void openTextCartella(Player p) {
        Inventory text = Bukkit.createInventory(null, InventoryType.ANVIL, "cartella");
        text.setItem(0, createItem(Material.PAPER, " ", 9));
        p.openInventory(text);
    }

    public static void openTextFile(Player p) {
        Inventory text = Bukkit.createInventory(null, InventoryType.ANVIL, "file");
        text.setItem(0, createItem(Material.PAPER, " ", 9));
        p.openInventory(text);
    }

    @EventHandler
    public void onAnvilClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;

        Player p = (Player) e.getWhoClicked();
        InventoryView view = e.getView();
        String title = view.getTitle();
        String type = "Cartella";
        String text = "Direzione";

        if (!title.equalsIgnoreCase("cartella") && !title.equalsIgnoreCase("file")) return;

        e.setCancelled(true);

        p.closeInventory();
        p.sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§6ʟᴏɢ §7» §fErrore nel codice, contatta un amministratore."));
        p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§6ᴄᴏᴍᴘᴜᴛᴇʀ §7» §f" + type +" creata: §f§n" + text));


        if (e.getRawSlot() == 2) {
                ItemStack result = e.getCurrentItem();
                if (result == null || result.getType().isAir()) return;

                ItemMeta meta = result.getItemMeta();
                if (meta == null || !meta.hasDisplayName()) return;

                text = meta.getDisplayName();

                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§6ᴄᴏᴍᴘᴜᴛᴇʀ §7» §fCartella/file creata: §f" + text));
        }
    }


// p.sendMessage("§6ʟᴏɢ §7» §fC'è stato un problema nel codice, nessun messaggio mandato.");

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player p = (Player) event.getWhoClicked();

        if (event.getView().getTitle().equals("§fᴄᴏᴍᴘᴜᴛᴇʀ")) {
            event.setCancelled(true);

            switch (event.getRawSlot()) {
                case 48:
                    p.closeInventory(); // torna indietro
                    break;
                case 49:
                    openTextFile(p); // aggiungi un file
                    break;
                case 50:
                    openTextCartella(p); // aggiungi una cartella
                    break;
            }
        }

        if (event.getView().getTitle().equals("text")) {

            if (event.getRawSlot() == 2) {
                openGUI(p);
                event.setCancelled(true);
            } else {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTitle().equals("§fᴄᴏᴍᴘᴜᴛᴇʀ")) {
            event.setCancelled(true);
        }

        if (event.getView().getTitle().equals("text")) {
            event.setCancelled(true);
        }
    }
}