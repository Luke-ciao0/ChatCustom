package org.core;

import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.core.Listener.ChatListener;

public final class main extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        System.out.println("Il plugin è in avvio.");
        // lista comandi
        getCommand("actionbar").setExecutor(new ActionBar());
        getCommand("title").setExecutor(new Titolo());
        getCommand("message").setExecutor(new Message());

        // lista comandi tabbabili
        getCommand("actionbar").setTabCompleter(new ActionBar());
        getCommand("title").setTabCompleter(new Titolo());
        getCommand("message").setTabCompleter(new Message());

        // lista Listener
        getServer().getPluginManager().registerEvents(new ChatListener(), this);
    }

    @Override
    public void onDisable() {
        System.out.println("Il plugin si sta spegnendo.");
    }
}
